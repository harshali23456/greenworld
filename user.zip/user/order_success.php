<!DOCTYPE html>
<html lang="en">
    <?php include '../components/userMeta.php'; ?>
    <body>
        <!-- Preloader -->
        <div class="preloader d-flex align-items-center justify-content-center">
            <div class="preloader-circle"></div>
            <div class="preloader-img">
                <img src="../images/img/core-img/leaf.png" alt="Preloader Image" />
            </div>
        </div>

        <!-- Header -->
        <?php include('../components/userHeader.php'); ?>

        <!-- Success Message -->
        <div class="custom-container">
            <div class="row">
                <div class="col-12 flex">
                    <h2>Your order has been placed successfully!</h2>
                    <p>Thank you for shopping with us. Your order will be processed shortly.</p>
                    <a href="/greenworld/user/view_orders.php" class="btn alazea-btn">View Your Orders</a>
                </div>
            </div>
        </div>

        <!-- Scripts -->
        <?php include('../components/userScripts.php'); ?>
    </body>
</html>
